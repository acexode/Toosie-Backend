export interface dbConfig {
  host: string;
  port: number;
  database: string;
}
